from django.apps import AppConfig


class CoronaTweetAnalysisConfig(AppConfig):
    name = 'corona_tweet_analysis'
