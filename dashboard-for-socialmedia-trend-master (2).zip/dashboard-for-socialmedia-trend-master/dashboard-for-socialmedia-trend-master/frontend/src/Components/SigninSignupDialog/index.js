import SigninSignupDialog from './Component';

export default SigninSignupDialog;