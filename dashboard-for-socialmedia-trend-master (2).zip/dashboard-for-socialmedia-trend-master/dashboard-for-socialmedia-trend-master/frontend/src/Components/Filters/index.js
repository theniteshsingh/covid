import Filters from './Component';

export default Filters;