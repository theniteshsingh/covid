import Masthead from './Component';

export default Masthead;