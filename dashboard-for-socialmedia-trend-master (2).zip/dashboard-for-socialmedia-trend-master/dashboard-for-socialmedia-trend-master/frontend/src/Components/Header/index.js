import Header from './Component';

export default Header;