import Nav from './Component';

export default Nav;