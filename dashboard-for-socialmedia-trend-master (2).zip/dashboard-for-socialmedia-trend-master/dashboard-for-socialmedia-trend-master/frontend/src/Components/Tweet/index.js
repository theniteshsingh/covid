import Tweet from "./Component";
export { TweetLoading } from "./Component";

export default Tweet;
