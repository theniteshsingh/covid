import Footer from './Component';

export default Footer;