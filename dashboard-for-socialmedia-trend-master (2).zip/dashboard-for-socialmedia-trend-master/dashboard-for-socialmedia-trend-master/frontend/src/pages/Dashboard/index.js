import Next from './Component';

export default Next;