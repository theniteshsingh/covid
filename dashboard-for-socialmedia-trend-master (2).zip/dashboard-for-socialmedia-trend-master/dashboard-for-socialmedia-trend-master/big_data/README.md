## Big Data Platform using PySpark CLI Platform

Crunching tweets from twitter.com and categorizing
