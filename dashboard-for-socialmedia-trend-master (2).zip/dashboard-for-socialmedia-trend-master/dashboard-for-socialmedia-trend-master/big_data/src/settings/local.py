DATA_SOURCE = '/home/qburst/Downloads/spark-2.4.4-bin-hadoop2.7/README.md'
MASTER_URL = 'local'